/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     Y_CAST = 258,
     Y_DECLARE = 259,
     Y_EXPLAIN = 260,
     Y_HELP = 261,
     Y_SET = 262,
     Y_QUIT = 263,
     Y_ARRAY = 264,
     Y_AS = 265,
     Y_BLOCK = 266,
     Y_DYNAMIC = 267,
     Y_FUNCTION = 268,
     Y_INTO = 269,
     Y_LENGTH = 270,
     Y_MEMBER = 271,
     Y_OF = 272,
     Y_POINTER = 273,
     Y_PURE = 274,
     Y_REFERENCE = 275,
     Y_REINTERPRET = 276,
     Y_RETURNING = 277,
     Y_RVALUE = 278,
     Y_TO = 279,
     Y_VARIABLE = 280,
     Y_ARROW = 281,
     Y_AUTO_C = 282,
     Y_CHAR = 283,
     Y_DOUBLE = 284,
     Y_EXTERN = 285,
     Y_FLOAT = 286,
     Y_INT = 287,
     Y_LONG = 288,
     Y_REGISTER = 289,
     Y_SHORT = 290,
     Y_STATIC = 291,
     Y_STRUCT = 292,
     Y_TYPEDEF = 293,
     Y_UNION = 294,
     Y_UNSIGNED = 295,
     Y_CONST = 296,
     Y_ELLIPSIS = 297,
     Y_ENUM = 298,
     Y_SIGNED = 299,
     Y_SIZE_T = 300,
     Y_SSIZE_T = 301,
     Y_VOID = 302,
     Y_VOLATILE = 303,
     Y_WCHAR_T = 304,
     Y_BOOL = 305,
     Y_COMPLEX = 306,
     Y_INLINE = 307,
     Y_RESTRICT = 308,
     Y_ATOMIC_QUAL = 309,
     Y_ATOMIC_SPEC = 310,
     Y_NORETURN = 311,
     Y_CLASS = 312,
     Y_COLON_COLON = 313,
     Y_CONST_CAST = 314,
     Y_DYNAMIC_CAST = 315,
     Y_FRIEND = 316,
     Y_MUTABLE = 317,
     Y_REINTERPRET_CAST = 318,
     Y_STATIC_CAST = 319,
     Y_VIRTUAL = 320,
     Y_AUTO_CPP_11 = 321,
     Y_CONSTEXPR = 322,
     Y_FINAL = 323,
     Y_OVERRIDE = 324,
     Y_DOUBLE_AMPERSAND = 325,
     Y_CHAR16_T = 326,
     Y_CHAR32_T = 327,
     Y_THREAD_LOCAL = 328,
     Y___BLOCK = 329,
     Y_CPP_LANG_NAME = 330,
     Y_END = 331,
     Y_ERROR = 332,
     Y_NAME = 333,
     Y_NUMBER = 334
   };
#endif
/* Tokens.  */
#define Y_CAST 258
#define Y_DECLARE 259
#define Y_EXPLAIN 260
#define Y_HELP 261
#define Y_SET 262
#define Y_QUIT 263
#define Y_ARRAY 264
#define Y_AS 265
#define Y_BLOCK 266
#define Y_DYNAMIC 267
#define Y_FUNCTION 268
#define Y_INTO 269
#define Y_LENGTH 270
#define Y_MEMBER 271
#define Y_OF 272
#define Y_POINTER 273
#define Y_PURE 274
#define Y_REFERENCE 275
#define Y_REINTERPRET 276
#define Y_RETURNING 277
#define Y_RVALUE 278
#define Y_TO 279
#define Y_VARIABLE 280
#define Y_ARROW 281
#define Y_AUTO_C 282
#define Y_CHAR 283
#define Y_DOUBLE 284
#define Y_EXTERN 285
#define Y_FLOAT 286
#define Y_INT 287
#define Y_LONG 288
#define Y_REGISTER 289
#define Y_SHORT 290
#define Y_STATIC 291
#define Y_STRUCT 292
#define Y_TYPEDEF 293
#define Y_UNION 294
#define Y_UNSIGNED 295
#define Y_CONST 296
#define Y_ELLIPSIS 297
#define Y_ENUM 298
#define Y_SIGNED 299
#define Y_SIZE_T 300
#define Y_SSIZE_T 301
#define Y_VOID 302
#define Y_VOLATILE 303
#define Y_WCHAR_T 304
#define Y_BOOL 305
#define Y_COMPLEX 306
#define Y_INLINE 307
#define Y_RESTRICT 308
#define Y_ATOMIC_QUAL 309
#define Y_ATOMIC_SPEC 310
#define Y_NORETURN 311
#define Y_CLASS 312
#define Y_COLON_COLON 313
#define Y_CONST_CAST 314
#define Y_DYNAMIC_CAST 315
#define Y_FRIEND 316
#define Y_MUTABLE 317
#define Y_REINTERPRET_CAST 318
#define Y_STATIC_CAST 319
#define Y_VIRTUAL 320
#define Y_AUTO_CPP_11 321
#define Y_CONSTEXPR 322
#define Y_FINAL 323
#define Y_OVERRIDE 324
#define Y_DOUBLE_AMPERSAND 325
#define Y_CHAR16_T 326
#define Y_CHAR32_T 327
#define Y_THREAD_LOCAL 328
#define Y___BLOCK 329
#define Y_CPP_LANG_NAME 330
#define Y_END 331
#define Y_ERROR 332
#define Y_NAME 333
#define Y_NUMBER 334




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 327 "parser.y"
{
  c_ast_t      *ast;
  c_ast_list_t  ast_list; /* for function arguments */
  c_ast_pair_t  ast_pair; /* for the AST being built */
  char const   *name;     /* name being declared or explained */
  char const   *literal;  /* token literal (used for new-style casts)*/
  int           number;   /* for array sizes */
  c_type_t      type;     /* built-in types, storage classes, & qualifiers */
}
/* Line 1529 of yacc.c.  */
#line 217 "parser.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;
