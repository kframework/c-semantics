Note that cdecl-3.x has no affiliation with the cdecl.org site that, as of this
writing, still uses cdecl 2.x.

Paul J. Lucas
paul@lucasmail.org
San Francisco, California, USA
30 April 2017


The ridiculous_fish README follows:
-----
This is cdecl, the C gibberish translator. This version has been enhanced
by ridiculous_fish to support Apple's blocks syntax.

Visit https://cdecl.org to use it online.
